import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
import matplotlib.pyplot as plt
import seaborn as sns


data = {
    "income": [50000, 60000, 25000, 80000, 120000, 30000, 70000, 40000, 90000, 100000,
               45000, 52000, 28000, 75000, 110000, 35000, 68000, 42000, 95000, 105000],
    
    "debt": [20000, 15000, 10000, 30000, 40000, 5000, 20000, 15000, 25000, 35000,
             18000, 16000, 8000, 27000, 38000, 6000, 21000, 14000, 24000, 33000],
    
    "payment_history": [1,1,0,1,1,0,1,0,1,1, 1,1,0,1,1,0,1,0,1,1],
    
    "loan_amount": [10000,20000,5000,25000,30000,7000,15000,12000,22000,28000,
                    11000,18000,6000,24000,29000,8000,16000,13000,23000,27000],
    
    "creditworthy": [1,1,0,1,1,0,1,0,1,1, 1,1,0,1,1,0,1,0,1,1]
}

df = pd.DataFrame(data)


X = df.drop("creditworthy", axis=1)
y = df["creditworthy"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)


log_model = LogisticRegression()
log_model.fit(X_train, y_train)

rf_model = RandomForestClassifier()
rf_model.fit(X_train, y_train)


rf_pred = rf_model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, rf_pred))
print("\nClassification Report:")
print(classification_report(y_test, rf_pred))

print("ROC-AUC Score:", roc_auc_score(y_test, rf_model.predict_proba(X_test)[:,1]))


cm = confusion_matrix(y_test, rf_pred)

plt.figure()
sns.heatmap(cm, annot=True)
plt.title("Confusion Matrix - Credit Scoring")
plt.show()
