# CodeAlpha Internship - Credit Scoring Model

## 📌 Project Overview

This project predicts whether a customer is creditworthy based on financial attributes such as income, debt, payment history, and loan amount.

It is developed as part of the CodeAlpha Machine Learning Internship.

---

## 🎯 Objective

To build a classification model that evaluates an individual's creditworthiness using financial data.

---

## 📊 Features Used

- Income
- Debt
- Payment History
- Loan Amount

Target:
- 0 → Not Creditworthy
- 1 → Creditworthy

---

## 🧠 Algorithms Used

- Logistic Regression
- Random Forest Classifier

---

## 📈 Evaluation Metrics

- Accuracy
- Precision
- Recall
- F1-Score
- ROC-AUC Score
- Confusion Matrix

---

## 🛠️ Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

---

## 🚀 How to Run

