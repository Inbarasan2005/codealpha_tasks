# CodeAlpha Internship - Disease Prediction Model

## 📌 Project Overview

This project is developed as part of the CodeAlpha Machine Learning Internship.

The objective of this project is to build a machine learning model that can predict the possibility of a disease using structured medical data.

In this implementation, the Breast Cancer dataset from Scikit-learn is used to classify whether a tumor is malignant or benign.

---

## 🎯 Objective

To apply supervised machine learning algorithms to medical data and evaluate their performance using classification metrics.

---

## 📊 Dataset Used

- Breast Cancer Dataset (from Scikit-learn)
- Features include various medical measurements of tumors
- Target:
  - 0 → Malignant
  - 1 → Benign

---

## 🧠 Algorithms Used

- Logistic Regression
- Random Forest Classifier

---

## 📈 Evaluation Metrics

The model performance was evaluated using:

- Accuracy Score
- Precision
- Recall
- F1-Score
- ROC-AUC Score
- Confusion Matrix

---

## 🛠️ Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

---

## 🚀 How to Run

1. Install dependencies:
