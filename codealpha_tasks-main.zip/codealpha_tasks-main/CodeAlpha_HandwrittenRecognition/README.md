# CodeAlpha Internship - Handwritten Digit Recognition

## 📌 Project Overview

This project builds a machine learning model to recognize handwritten digits (0-9).

The model is trained using the MNIST-like digits dataset available in Scikit-learn.

---

## 🎯 Objective

To classify handwritten digit images into their respective numeric classes using supervised learning.

---

## 📊 Dataset Used

- Scikit-learn Digits Dataset
- 8x8 grayscale images of handwritten digits
- 10 classes (0-9)

---

## 🧠 Algorithm Used

- Logistic Regression

---

## 📈 Evaluation Metrics

- Accuracy
- Precision
- Recall
- F1-Score
- Confusion Matrix

---

## 🛠️ Technologies Used

- Python
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

---

## 🚀 How to Run

