# Handwritten Digit Recognition using ML

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# ----------------------------
# Step 1: Load Dataset
# ----------------------------

digits = load_digits()
X = digits.data
y = digits.target

# ----------------------------
# Step 2: Split Data
# ----------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ----------------------------
# Step 3: Train Model
# ----------------------------

model = LogisticRegression(max_iter=5000)
model.fit(X_train, y_train)

# ----------------------------
# Step 4: Predict
# ----------------------------

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# ----------------------------
# Step 5: Confusion Matrix
# ----------------------------

cm = confusion_matrix(y_test, y_pred)

plt.figure()
sns.heatmap(cm, annot=True)
plt.title("Confusion Matrix - Handwritten Recognition")
plt.show()
